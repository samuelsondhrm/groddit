#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "header/PostTree.h"
#include "header/list.h"

/* =========================================================
   HELPER PRINT
   ========================================================= */

static void printIndent(int depth) {
    for (int i = 0; i < depth; i++) printf("  ");
}

static void printNodeRec(AddrComment node, int depth) {
    printIndent(depth);

    printf("- (%d) ", node->data.comment_id);
    PrintSentence(node->data.content);
    printf("\n");

    Address p = FIRST(node->children);
    while (p != NULL) {
        AddrComment child = (AddrComment) INFO(p);
        printNodeRec(child, depth + 1);
        p = NEXT(p);
    }
}

/* =========================================================
   INTERNAL DELETE (RECURSIVE)
   ========================================================= */

static void deleteRec(AddrComment node) {
    Address p = FIRST(node->children);
    while (p != NULL) {
        deleteRec((AddrComment) INFO(p));
        p = NEXT(p);
    }
    free(node);
}

/* =========================================================
   CREATE TREE
   ========================================================= */

void CreatePostTree(PostTree *T, Post p) {
    T->root = p;
    CreateList(&(T->children));
}

/* =========================================================
   COMMENT NODE
   ========================================================= */

AddrComment NewCommentNode(Comment c) {
    AddrComment node = (AddrComment) malloc(sizeof(CommentNode));
    node->data = c;
    CreateList(&(node->children));
    return node;
}

/* =========================================================
   ADD COMMENT
   ========================================================= */

void AddCommentToRoot(PostTree *T, Comment c) {
    AddrComment newNode = NewCommentNode(c);
    InsertLast(&(T->children), newNode);
}

void AddCommentToNode(AddrComment parent, Comment c) {
    AddrComment newNode = NewCommentNode(c);
    InsertLast(&(parent->children), newNode);
}

void AddComment(PostTree *T, int parent_comment_id, Comment c) {
    if (parent_comment_id == -1) {
        AddCommentToRoot(T, c);
        return;
    }

    AddrComment parent = FindCommentInTree(T, parent_comment_id);
    if (parent == NULL) {
        printf("Komentar parent %d tidak ditemukan!\n", parent_comment_id);
        return;
    }

    AddCommentToNode(parent, c);
}

/* =========================================================
   FIND COMMENT (DFS)
   ========================================================= */

AddrComment FindCommentDFS(AddrComment root, int comment_id) {
    if (root->data.comment_id == comment_id) return root;

    Address p = FIRST(root->children);
    while (p != NULL) {
        AddrComment res = FindCommentDFS((AddrComment) INFO(p), comment_id);
        if (res != NULL) return res;
        p = NEXT(p);
    }
    return NULL;
}

AddrComment FindCommentInTree(PostTree *T, int comment_id) {
    Address p = FIRST(T->children);
    while (p != NULL) {
        AddrComment child = (AddrComment) INFO(p);
        AddrComment res = FindCommentDFS(child, comment_id);
        if (res != NULL) return res;
        p = NEXT(p);
    }
    return NULL;
}

/* =========================================================
   DELETE SUBTREE
   ========================================================= */

void DeleteCommentSubtree(PostTree *T, int comment_id) {

    /* 1. cek jika dia anak langsung root */
    Address p = FIRST(T->children);
    Address prev = NULL;

    while (p != NULL) {
        AddrComment node = (AddrComment) INFO(p);

        if (node->data.comment_id == comment_id) {
            if (prev == NULL) {
                FIRST(T->children) = NEXT(p);
            } else {
                NEXT(prev) = NEXT(p);
            }
            deleteRec(node);
            return;
        }

        prev = p;
        p = NEXT(p);
    }

    /* 2. kalau bukan root-level comment, cari parent di subtree */
    Address q = FIRST(T->children);
    while (q != NULL) {
        AddrComment parent = (AddrComment) INFO(q);

        Address pc = FIRST(parent->children);
        Address pprev = NULL;

        while (pc != NULL) {
            AddrComment child = (AddrComment) INFO(pc);

            if (child->data.comment_id == comment_id) {
                if (pprev == NULL)
                    FIRST(parent->children) = NEXT(pc);
                else
                    NEXT(pprev) = NEXT(pc);

                deleteRec(child);
                return;
            }

            pprev = pc;
            pc = NEXT(pc);
        }

        q = NEXT(q);
    }
}

/* =========================================================
   PRINT
   ========================================================= */

void PrintPostTree(PostTree *T) {
    Address p = FIRST(T->children);
    while (p != NULL) {
        printNodeRec((AddrComment) INFO(p), 0);
        p = NEXT(p);
    }
}
