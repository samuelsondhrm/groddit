#ifndef POSTTREE_H
#define POSTTREE_H

#include "adt-sederhana.h"
#include "ListBerkait.h"      // ADT List Berkait tubes

/* ---------------------------------------------------------
   NODE KOMENTAR 
   (setiap node menyimpan struct Comment + children)
   --------------------------------------------------------- */

typedef struct CommentNode *AddrComment;

typedef struct CommentNode {
    Comment data;      // data komentar
    List children;     // list berkait of AddrComment
} CommentNode;

/* ---------------------------------------------------------
   POST TREE
   Root = Post
   Children = list of CommentNode*
   --------------------------------------------------------- */

typedef struct {
    Post root;         // data post (akar)
    List children;     // komentar level-1 (List of AddrComment)
} PostTree;

/* =========================================================
   PRIMITIVES
   ========================================================= */

/* ---------- Create Tree dari sebuah Post ---------- */
void CreatePostTree(PostTree *T, Post p);

/* ---------- Buat CommentNode baru ---------- */
AddrComment NewCommentNode(Comment c);

/* ---------- Tambah komentar ----------
   parent_comment_id = -1  → komentar level 1
   parent_comment_id >= 0  → reply ke komentar lain
--------------------------------------------------------- */
void AddCommentToRoot(PostTree *T, Comment c);
void AddCommentToNode(AddrComment parent, Comment c);
void AddComment(PostTree *T, int parent_comment_id, Comment c);

/* ---------- Cari komentar by ID (DFS) ---------- */
AddrComment FindCommentDFS(AddrComment root, int comment_id);
AddrComment FindCommentInTree(PostTree *T, int comment_id);

/* ---------- Hapus subtree komentar ---------- */
void DeleteCommentSubtree(PostTree *T, int comment_id);

/* ---------- Print pohon komentar ---------- */
void PrintPostTree(PostTree *T);

#endif